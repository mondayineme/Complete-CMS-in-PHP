<?php
include("includes/connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Blog</title>

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" href="css/style.css">

</head>

<body>
<?php include("includes/header.php"); ?>

<div class="widewrapper main"><!-- Widewrapper main starts -->
<div class="container"><!--- Container Starts --->
<div class="row"><!--- Row Starts -->
<div class="col-md-8 blog-main"><!--- col-md-8 blog-main starts -->

<div class="row"><!-- Row Starts -->
<?php
if(isset($_GET['search'])){

$get_query = $_GET['search_query'];

$get_posts = "select * from blog_posts where post_keywords like '%$get_query%' order by post_id ASC";

$run_posts = mysqli_query($con,$get_posts);

$count = mysqli_num_rows($run_posts);
if($count==0){
echo "<h1>No Search Results Found</h1>";
}else{

while($row_posts = mysqli_fetch_array($run_posts)){
$post_id = $row_posts['post_id'];
$post_title = $row_posts['post_title'];
$post_date = $row_posts['post_date'];
$post_author = $row_posts['post_author'];
$post_image = $row_posts['post_image'];
$post_content = substr($row_posts['post_content'],0,300);

echo "
<div class='col-md-6 col-sm-6'><!-- col-md-6 col-sm-6 Starts --->
<article class='blog-teaser'><!-- blog-teaser Starts -->

<header><!-- Header Starts -->
<img src='admin/post_images/$post_image' width='183' height='183' >
<h3><a href='blog-detail.php?post=$post_id'>$post_title</a></h3>
<span class='meta'>$post_date, $post_author</span>
<hr>
</header><!-- Header Ends -->

<div class='body'>
$post_content
</div>

<div class='clearfix'><!-- div clearfix Starts -->
<a href='blog-detail.php?post=$post_id' class='btn btn-blog-one'> Read More </a>
</div><!-- div clearfix Ends -->

</article><!-- blog-teaser Ends -->
</div><!-- col-md-6 col-sm-6 Ends --->
";

}

}

}

?>
</div><!-- Row Ends -->

</div><!--- col-md-8 blog-main Ends -->
<?php include("includes/sidebar.php"); ?>
</div><!--- Row Ends -->
</div><!--- Container Ends --->
</div><!-- Widewrapper main Ends -->

<?php include("includes/footer.php"); ?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>