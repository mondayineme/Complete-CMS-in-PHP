<?php
include("includes/connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Blog</title>

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" href="css/style.css">

</head>

<body>
<?php include("includes/header.php"); ?>

<div class="widewrapper main"><!-- Widewrapper main starts -->
<div class="container about"><!-- container about Starts -->
<h1>Hello There, I am <span class="about-bold">Mohammed Tahir Ahmed </span></h1>

<span class="about-large"><!--- about-large Starts --->
<span class="about-italic"><!--- about-italic Starts -->
It is a long established fact that a reader will be distracted by the 

</span><!--- about-italic Ends -->
<br>
<img src="img/about-me.jpg" class="about-portrait img-responsive">
</span><!--- about-large Ends --->

<span class="about-small">
readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem

</span>

<div class="about-button"><!-- about-button Starts --->
<a class="btn btn-xlarge btn-blog-one" href="#contact">Drop Me A Line</a>
</div><!-- about-button Ends --->
<hr>

</div><!-- container about Ends -->

<div class="container"><!--- container Starts --->

<?php include("includes/contact_form.php"); ?>

</div><!--- container Ends --->

</div><!-- Widewrapper main Ends -->

<?php include("includes/footer.php"); ?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>