<?php
include("includes/connection.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Blog</title>

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" href="css/style.css">

</head>

<body>
<?php include("includes/header.php"); ?>

<div class="widewrapper main"><!-- Widewrapper main starts -->
<div class="container"><!--- Container Starts --->
<div class="row"><!--- Row Starts -->
<div class="col-md-8 blog-main"><!--- col-md-8 blog-main starts -->

<?php include("includes/get_cats.php"); ?>

<?php include("includes/post_body.php"); ?>

</div><!--- col-md-8 blog-main Ends -->
<?php include("includes/sidebar.php"); ?>
</div><!--- Row Ends -->
</div><!--- Container Ends --->
</div><!-- Widewrapper main Ends -->

<?php include("includes/footer.php"); ?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>