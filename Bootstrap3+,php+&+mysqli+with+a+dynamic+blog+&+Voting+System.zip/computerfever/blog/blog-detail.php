<?php
include("includes/connection.php");

if(isset($_GET['post'])){
$post_id = $_GET['post'];
$get_posts = "select * from blog_posts where post_id=$post_id";
$run_posts = mysqli_query($con, $get_posts);
$row_posts = mysqli_fetch_array($run_posts);

$post_title = $row_posts['post_title'];
$post_date = $row_posts['post_date'];
$post_cat = $row_posts['category_id'];
$post_author = $row_posts['post_author'];
$post_image = $row_posts['post_image'];
$post_content = $row_posts['post_content'];

//Select categories from table

$sel_cat = "select * from categories where category_id='$post_cat'";
$run_cat = mysqli_query($con, $sel_cat);
$row_cats = mysqli_fetch_array($run_cat);
$category_id = $row_cats['category_id'];
$category_title = $row_cats['category_title'];

}

?>
<!DOCTYPE html>
<html>
<head>
<title>Blog</title>

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

<link rel="stylesheet" href="css/style.css">

</head>

<body>

<!-- header.php page Starts -->

<header><!-- Header Starts-->
<div class="widewrapper masthead"><!-- Widewrapper masthead starts -->
<div class="container"><!-- container Starts -->
<nav class="navbar navbar-custom"><!-- Nav Starts-->
<div class="container"><!-- container Starts -->
<div class="navbar-header"><!--- navbar-header Starts -->
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
<i class="fa fa-bars fa-lg fa-fw"></i>
</button>
<a class="navbar-brand page-scroll" href="index.php" style="font-size:30px;">
Blog
</a>
</div><!--- navbar-header Ends -->
<div class="collapse navbar-collapse navbar-right navbar-main-collapse"><!-- collapse navbar-collapse navbar-right navbar-main-collapse Starts -->
<ul class="nav navbar-nav"><!-- nav navbar-nav Starts -->
<li><a href="index.php">Home</a></li>
<?php
$get_cat = "select * from categories";
$run_cat = mysqli_query($con,$get_cat);
while($row_cat=mysqli_fetch_array($run_cat)) {
$cat_id = $row_cat['category_id'];
$cat_title = $row_cat['category_title'];
echo "<li><a href='index.php?cat=$cat_id'>$cat_title</a></li>";
}
?>
<li><a href="about-us.php">About Us</a></li>

</ul><!-- nav navbar-nav Ends -->
</div><!-- collapse navbar-collapse navbar-right navbar-main-collapse Ends -->
</div><!-- container Ends -->
</nav><!-- Nav Ends-->
</div><!-- container Ends -->
</div><!-- Widewrapper masthead Ends -->
<div class="widewrapper subheader"><!-- Widewrapper  Subheader Starts -->
<div class="container"><!-- Container Starts -->
<div class="blog-breadcrumb"><!-- Blog Breadcrumb Starts -->
<a href="index.php">
Blog
</a>
<span class="separator">&#x2F;</span>
<a href="index.php?cat=<?php echo $category_id; ?>"><?php echo $category_title; ?></a>
<span class="separator">&#x2F;</span>
<a href="#"><?php echo $post_title; ?></a>
</div><!-- Blog Breadcrumb Ends -->
<div class="blog-searchbox"><!-- Blog Search Box Starts -->
<form action="search.php" method="get" enctype="multipart/form-data"><!-- Search Form -->
<button class="searchbutton" type="submit" name="search">
<i class="fa fa-search"></i>
</button>
<input class="searchfield" id="searchbox" type="text" name="search_query" placeholder="Search A Post">

</form><!-- Search Form Ends-->
</div><!-- Blog Search Box Ends -->
</div><!-- Container Ends -->
</div><!-- Widewrapper  Subheader Ends -->
</header><!-- Header Ends-->


<!-- header.php page Ends -->

<div class="widewrapper main"><!-- Widewrapper main starts -->
<div class="container"><!--- Container Starts --->
<div class="row"><!--- Row Starts -->
<div class="col-md-8 blog-main"><!--- col-md-8 blog-main starts -->

<article class="blog-post"><!-- Article Starts -->
<header><!-- Article Header Starts -->
<h1><?php echo $post_title; ?></h1>

<div class="lead-image"><!--- Article lead-image Starts -->
<img src="admin/post_images/<?php echo $post_image; ?>" width="740" height="280" class="img-responsive">
<div class="meta clearfix"><!--- Article meta clearfix Starts --->
<div class="author"><!--- Article author Starts --->
<i class="fa fa-user"></i>
<span class="data"><?php echo $post_author; ?></span>

</div><!--- Article author Ends --->

<div class="date"><!--- Article date Starts --->
<i class="fa fa-calendar"></i>
<span class="data"><?php echo $post_date; ?></span>
</div><!--- Article date Ends --->

<div class="comments"><!--- Article comments Starts --->
<i class="fa fa-comments"></i>
<span class="data"><a href="#">4 Comments</a></span>
</div><!--- Article comments Ends --->

</div><!--- Article meta clearfix Ends --->
</div><!--- Article lead-image Ends -->

</header><!-- Article Header Ends -->

<div class="body">
<?php echo $post_content; ?>
</div>

</article><!-- Article Ends -->

<?php include("includes/comment_form.php"); ?>

</div><!--- col-md-8 blog-main Ends -->
<?php include("includes/sidebar.php"); ?>
</div><!--- Row Ends -->
</div><!--- Container Ends --->
</div><!-- Widewrapper main Ends -->

<?php include("includes/footer.php"); ?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html>