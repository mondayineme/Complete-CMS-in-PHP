<aside class="col-md-4 blog-aside"><!-- Blog Aside Starts -->
<div class="aside-widget"><!-- Aside Subscribe Us Widget Starts -->
<header><!-- Header Starts-->
<h3>Subscribe Us</h3>
</header><!-- Header Ends-->
<div class="body"><!--Body Starts-->
<form style="border:1px solid #ccc;padding:3px;text-align:center;" action="https://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=computerfever', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true"><p>Enter your email address:</p><p><input type="text" style="width:140px" name="email"/></p><input type="hidden" value="computerfever" name="uri"/><input type="hidden" name="loc" value="en_US"/><input type="submit" value="Subscribe" /><p>Delivered by <a href="https://feedburner.google.com" target="_blank">FeedBurner</a></p></form>
</div><!--Body Ends-->
</div><!-- Aside Subscribe Us Widget Ends -->

<div class="aside-widget"><!--- Aside Recent Posts Widget Starts -->
<header><!-- Header Starts-->
<h3>Recent Posts</h3>
</header><!-- Header Ends-->
<div class="body"><!-- Body Starts-->
<ul class="blog-list">

<?php

$get_posts = "select * from blog_posts LIMIT 0,5";

$run_posts = mysqli_query($con,$get_posts);

while($row_posts=mysqli_fetch_array($run_posts)){

$post_id = $row_posts['post_id'];
$post_title = $row_posts['post_title'];
$post_date = $row_posts['post_date'];
$post_author = $row_posts['post_author'];

echo "
<li>
<a href='blog-detail.php?post=$post_id'>$post_title</a>
<br> $post_date, By $post_author
</li>
";

}

?>

</ul>
</div><!-- Body Ends-->
</div><!--- Aside Recent Posts Widget Ends -->

<div class="aside-widget"><!-- Aside Facebook Like Box Widget Starts-->
<header><!--- Header Starts-->
<h3>Facebook Like Box</h3>
</header><!--- Header Ends-->
<div class="body clearfix"><!-- Body Starts-->
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fcomputerfevers&tabs&width=340&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="270" height="214" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
</div><!-- Body Ends-->
</div><!-- Aside Facebook Like Box Widget Ends-->

</aside><!-- Blog Aside Ends -->




