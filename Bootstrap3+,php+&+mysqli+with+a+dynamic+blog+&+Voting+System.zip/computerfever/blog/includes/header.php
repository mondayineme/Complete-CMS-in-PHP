<header><!-- Header Starts-->
<div class="widewrapper masthead"><!-- Widewrapper masthead starts -->
<div class="container"><!-- container Starts -->
<nav class="navbar navbar-custom"><!-- Nav Starts-->
<div class="container"><!-- container Starts -->
<div class="navbar-header"><!--- navbar-header Starts -->
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
<i class="fa fa-bars fa-lg fa-fw"></i>
</button>
<a class="navbar-brand page-scroll" href="index.php" style="font-size:30px;">
Blog
</a>
</div><!--- navbar-header Ends -->
<div class="collapse navbar-collapse navbar-right navbar-main-collapse"><!-- collapse navbar-collapse navbar-right navbar-main-collapse Starts -->
<ul class="nav navbar-nav"><!-- nav navbar-nav Starts -->
<li><a href="index.php">Home</a></li>
<?php
$get_cat = "select * from categories";
$run_cat = mysqli_query($con,$get_cat);
while($row_cat=mysqli_fetch_array($run_cat)) {
$cat_id = $row_cat['category_id'];
$cat_title = $row_cat['category_title'];
echo "<li><a href='index.php?cat=$cat_id'>$cat_title</a></li>";
}
?>
<li><a href="about-us.php">About Us</a></li>
</ul><!-- nav navbar-nav Ends -->
</div><!-- collapse navbar-collapse navbar-right navbar-main-collapse Ends -->
</div><!-- container Ends -->
</nav><!-- Nav Ends-->
</div><!-- container Ends -->
</div><!-- Widewrapper masthead Ends -->
<div class="widewrapper subheader"><!-- Widewrapper  Subheader Starts -->
<div class="container"><!-- Container Starts -->
<div class="blog-breadcrumb"><!-- Blog Breadcrumb Starts -->
<a href="index.php">
Blog
</a>
</div><!-- Blog Breadcrumb Ends -->
<div class="blog-searchbox"><!-- Blog Search Box Starts -->
<form action="search.php" method="get" enctype="multipart/form-data"><!-- Search Form -->
<button class="searchbutton" type="submit" name="search">
<i class="fa fa-search"></i>
</button>
<input class="searchfield" id="searchbox" type="text" name="search_query" placeholder="Search A Post">

</form><!-- Search Form Ends-->
</div><!-- Blog Search Box Ends -->
</div><!-- Container Ends -->
</div><!-- Widewrapper  Subheader Ends -->
</header><!-- Header Ends-->