<div class="row"><!-- Row Starts -->
<?php
if(isset($_GET['cat'])){
$cat_id = $_GET['cat'];

$get_posts = "select * from blog_posts where category_id=$cat_id order by post_id ASC";
$run_posts = mysqli_query($con, $get_posts);
$count = mysqli_num_rows($run_posts);

if($count==0){
echo "<h1>No Posts Found In this Category </h1>";
}
while($row_posts = mysqli_fetch_array($run_posts)){
$post_id = $row_posts['post_id'];
$post_title = $row_posts['post_title'];
$post_date = $row_posts['post_date'];
$post_author = $row_posts['post_author'];
$post_image = $row_posts['post_image'];
$post_content = substr($row_posts['post_content'],0,300);

echo "
<div class='col-md-6 col-sm-6'><!-- col-md-6 col-sm-6 Starts -->
<article class='blog-teaser'><!-- article blog-teaser Starts -->

<header><!-- header starts -->
<img src='admin/post_images/$post_image' width='183' height='183'>
<h3><a href='blog-detail.php?post=$post_id'>$post_title</a></h3>
<span class='meta'>$post_date, $post_author</span>
<hr>
</header><!-- header Ends -->

<div class='body'><!-- Body Starts -->
$post_content
</div><!-- Body Ends -->

<div class='clearfix'><!-- div clearfix Starts -->
<a href='blog-detail.php?post=$post_id' class='btn btn-blog-one'>Read more</a>
</div><!-- div clearfix Ends -->

</article><!-- article blog-teaser ends -->
</div><!-- col-md-6 col-sm-6 Ends -->
";

}

}
?>
</div><!-- Row Ends -->