<div class="row"><!--- row Starts --->

<div class="col-md-8 col-md-offset-2" id="contact"><!--- col-md-8 col-md-offset-2 Starts --->

<h1 style="text-align:center;">Contact</h1>

<form method="post" action="about-us.php" class="contact-form"><!-- contact-form Starts --->
<div class="row"><!-- row Starts -->

<div class="col-md-6"><!-- col-md-6 Starts -->
<input type="text" name="name" placeholder="Name" class="form-control input-lg">
</div><!-- col-md-6 Ends -->

<div class="col-md-6"><!-- col-md-6 Starts -->
<input type="text" name="subject" placeholder="Subject" class="form-control input-lg">
</div><!-- col-md-6 Ends -->

</div><!-- row Ends -->

<input type="email" name="email" placeholder="Email" class="form-control input-lg">

<textarea rows="10" name="message" placeholder="Your Thoughts... " class="form-control input-lg" ></textarea>

<div class="buttons clearfix"><!-- buttons clearfix Starts -->
<button type="submit" name="submit" class="btn btn-xlarge btn-blog-one">Submit</button>
</div><!-- buttons clearfix Ends -->
<br>
</form><!-- contact-form Ends --->

</div><!--- col-md-8 col-md-offset-2 Ends --->

</div><!--- row Ends --->

<?php
if(isset($_POST['submit'])){

// We receive email through this code

$sender_name = $_POST['name'];
$sender_subject = $_POST['subject'];
$sender_email = $_POST['email'];
$sender_message = $_POST['message'];
$receiver_email = "sad.ahmed22224@gmail.com";
if($sender_name=='' or $sender_email=='' or $sender_subject=='' or $sender_message==''){
echo "<script>alert('Please fill all the fields ')</script>";
exit();
}

mail($receiver_email,$sender_name,$sender_subject,$sender_message,$sender_email);

// Receiver mail and message

$email = $_POST['email'];
$subject = "Welcome to my web site";
$msg = "I shall get you soon,thanks for sending us email";
$from = "sad.ahmed22224@gmail.com";
mail($email,$subject,$msg,$from);
echo "<h2 align='center'>Your message has been sent successfully</h2>";
}

?>
