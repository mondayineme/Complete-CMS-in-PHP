<!--- start of pagination query --->
<?php

$per_page = 4;

if(isset($_GET['page'])){

$page = $_GET['page'];

}
else {

$page = 1;

}

$start_from = ($page-1) * $per_page;

//Selecting data from table but with limit

$data_query = "select * from blog_posts order by 1 DESC LIMIT $start_from, $per_page";
$result = mysqli_query($con, $data_query);

?>
<!--- ends of pagination query ---> 


<!--- select And View Posts Starts --->
<div class="row"><!-- row Starts --->
<?php
if(!isset($_GET['cat'])){

while($row_posts=mysqli_fetch_array($result)){

$post_id = $row_posts['post_id'];
$post_title = $row_posts['post_title'];
$post_date = $row_posts['post_date'];
$post_author = $row_posts['post_author'];
$post_image = $row_posts['post_image'];
$post_content = substr($row_posts['post_content'],0,300);

echo "
<div class='col-md-6 col-sm-6'><!-- col-md-6 col-sm-6 Starts -->
<article class='blog-teaser'><!--- blog-teaser Starts -->

<header>
<img src='admin/post_images/$post_image' width='183' height='183'>
<h3><a href='blog-detail.php?post=$post_id'> $post_title </a></h3>
<span class='meta'>$post_date, $post_author</span>
<hr>

</header>

<div class='body'>
$post_content
</div>

<div class='clearfix'>
<a href='blog-detail.php?post=$post_id' class='btn btn-blog-one'>Read More</a>
</div>

</article><!--- blog-teaser Ends -->
</div><!-- col-md-6 col-sm-6 Ends -->

";


}

}


?>
</div><!-- row Ends --->
<!--- select And View Posts Ends --->

<div class="paging"><!--- paging Starts --->
<?php
if(!isset($_GET['cat'])){

// Now select all from table
$query = "select * from blog_posts";
$result = mysqli_query($con, $query);

// count the total records
$total_records = mysqli_num_rows($result);

// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

// Going to first page

echo "
<a href='index.php?page=1' class='first'> 

<i class='fa fa-long-arrow-left'></i> First Page 

</a>

";

/// Show pagination Numbers

for ($i=1; $i<=$total_pages; $i++) {

echo "
<a href='index.php?page=".$i."'>".$i."</a>
";

}

// Going  to Last Page

echo "
<a href='#' class='last'>Last Page <i class='fa fa-long-arrow-right'></i> </a>
";


}

?>
</div><!--- paging Ends --->
