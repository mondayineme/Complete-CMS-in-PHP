<?php
if(isset($_GET['post'])){

$post_id = $_GET['post'];

$get_posts = "select * from blog_posts where post_id=$post_id";

$run_posts = mysqli_query($con,$get_posts);

$row_posts = mysqli_fetch_array($run_posts);

$post_new_id = $row_posts['post_id'];

}

?>

<?php

$get_comments = "select * from comments where post_id='$post_new_id' AND status='approve'";
$run_comments = mysqli_query($con,$get_comments);
$count = mysqli_num_rows($run_comments);


?>

<aside class="comments"><!--- Comments Starts --->

<h2><i class="fa fa-comments"></i> <?php echo $count; ?> Comments </h2>

<?php
while($row_comments=mysqli_fetch_array($run_comments)){

$comment_name = $row_comments['comment_name'];
$comment_date = $row_comments['comment_date'];
$comment_url = $row_comments['comment_url'];
$comment_text = $row_comments['comment_text'];

?>

<article class="comment"><!-- Article comment Starts -->

<header><!--- article comment header Starts -->
<img src="img/avatar.png" width="72" height="72" class="avatar">

<div class="meta"><!-- article comment meta Starts -->
<h3><a href="<?php echo $comment_url; ?>"><?php echo $comment_name; ?></a></h3>
<span class="date">
<?php echo $comment_date; ?>
</span>

<span class="separator">
-
</span>



</div><!-- article comment meta Ends -->

</header><!--- article comment header Ends -->

<div class="body">
<?php echo $comment_text; ?>
</div>

</article><!-- Article comment Ends -->
<?php } ?>

</aside><!--- Comments Ends --->

<aside class="create-comment"><!-- Create Comment Starts --> 

<hr>

<h2><i class="fa fa-heart"></i> Add Comment </h2>

<form method="post" action="blog-detail.php?post=<?php echo $post_new_id; ?>"><!--- Create Comment Form Starts -->
<div class="row"><!--- Create Comment Row Starts -->

<div class="col-md-6"><!-- Create Comment col-md-6 Starts --->
<input type="text" name="comment_name" placeholder="Name" class="form-control input-lg">
</div><!-- Create Comment col-md-6 Ends --->

<div class="col-md-6"><!-- Create Comment col-md-6 Starts -->
<input type="email" name="comment_email" placeholder="Email" class="form-control input-lg">
</div><!-- Create Comment col-md-6 Ends -->

</div><!--- Create Comment Row Ends -->

<input type="url" name="comment_url" placeholder="Website" class="form-control input-lg">

<textarea rows="10" name="comment" placeholder="Your Comments... " class="form-control input-lg"></textarea>

<div class="buttons clearfix">
<button type="submit" name="submit" class="btn btn-xlarge btn-blog-one">Submit</button>
</div>

</form><!--- Create Comment Form Ends -->

</aside><!-- Create Comment Ends --> 

<?php
if(isset($_POST['submit'])){

$post_com_id = $post_new_id;

$comment_name = $_POST['comment_name'];
$comment_email = $_POST['comment_email'];
$comment = $_POST['comment'];
$comment_url = $_POST['comment_url'];
$comment_date = date('d M Y');
$status = "unapprove";

if($comment_name=='' or $comment_email=='' or $comment_url=='' or $comment==''){
echo "<script>alert('Please fill all the fields')</script>";
echo "<script>window.open('blog-detail.php?post=$post_com_id','_self')</script>";
exit();
}else{

$insert_comment = "insert into comments (post_id,comment_name,comment_date,comment_email,comment_url,comment_text,status) values ('$post_com_id','$comment_name','$comment_date','$comment_email','$comment_url','$comment','$status')";

$run_query = mysqli_query($con,$insert_comment);

echo "<script>alert('Your comments will be Published after Approval ')</script>";
echo "<script>window.open('blog-detail.php?post=$post_com_id','_self')</script>";

}

}

?>