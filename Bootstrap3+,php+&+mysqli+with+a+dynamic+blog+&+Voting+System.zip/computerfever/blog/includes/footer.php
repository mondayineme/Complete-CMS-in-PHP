<footer><!-- Footer Starts -->
<div class="widewrapper footer"><!-- Widerapper Footer Starts -->
<div class="container"><!-- Container Starts-->
<div class="row"><!-- Row Starts --->
<div class="col-md-4 footer-widget"><!-- Footer Statistics Widget Starts -->
<h3>
<i class="fa fa-pied-piper"></i> Statistics
</h3>
<span>
Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
</span>
<div class="stats"><!-- Stats Starts -->

<div class="line"><!-- Line Starts -->
<span class="number">
<?php
$get_posts = "select * from blog_posts";
$run_posts = mysqli_query($con,$get_posts);
$count = mysqli_num_rows($run_posts);
echo $count;
?>
</span>
<span>Articles</span>
</div><!-- Line Ends -->

<div class="line"><!-- Line Starts -->
<span class="number">
<?php
$get_comments = "select * from comments where status='approve'";
$run_comments = mysqli_query($con,$get_comments);
$count_comments = mysqli_num_rows($run_comments);
echo $count_comments;
?>
</span>
<span>Comments</span>
</div><!-- Line Ends -->

</div><!-- Stats Ends -->

</div><!-- Footer Statistics Widget Ends -->

<div class="col-md-4 footer-widget"><!-- Footer Recent Posts Widget Starts -->
<h3>
<i class="fa fa-star"></i> Recent Posts
</h3>
<ul class="blog-list"><!-- Blog List Starts-->
<?php
$get_posts = "select * from blog_posts LIMIT 0,5";
$run_posts = mysqli_query($con,$get_posts);
while($row_posts=mysqli_fetch_array($run_posts)){
$post_id = $row_posts['post_id'];
$post_title = $row_posts['post_title'];

echo "
<li>
<a href='blog-detail.php?post=$post_id'>$post_title</a>
</li>
"; 

}

?>
</ul><!-- Blog List Ends-->

</div><!-- Footer Recent Posts Widget Ends -->

<div class="col-md-4 footer-widget"><!-- Footer Contact Me Widget Starts-->
<h3>
<i class="fa fa-envelope"></i> Contact Me
</h3>

<span>
It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
</span>

<span>
<a href="#">sad.ahmed22224@gmail.com</a>
</span>

</div><!-- Footer Contact Me Widget Ends-->



</div><!-- Row Ends --->
</div><!-- Container Ends-->
</div><!-- Widerapper Footer Ends -->

<div class="widewrapper copyright"><!-- Widerapper Copyright Starts -->
<div class="container"><!-- Container Starts -->
Designed By<a href="http://www.computerfever.com"> Saad Ahmed</a>

</div><!-- Container Ends -->

</div><!-- Widerapper Copyright Ends -->

</footer><!-- Footer Ends -->