<?php
@session_start();
include("includes/connection.php");

if(!isset($_SESSION['admin_email'])){
echo "<script>window.open('login.php','_self')</script>";
}else{


?>

<?php

if(isset($_GET['edit_post'])){

$edit_id = $_GET['edit_post'];

$select_post = "select * from blog_posts where post_id=$edit_id";

$run_post = mysqli_query($con,$select_post);

$row_post = mysqli_fetch_array($run_post);

$post_id = $row_post['post_id'];
$post_title = $row_post['post_title'];
$post_cat = $row_post['category_id'];
$post_author = $row_post['post_author'];
$post_keywords = $row_post['post_keywords'];
$post_content = $row_post['post_content'];
$post_image = $row_post['post_image'];


}

?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Post</title>
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>

</head>
<body>
<div class="row"><!-- Row Starts -->
<div class="col-lg-12"><!-- col-lg-12 Starts -->

<ol class="breadcrumb">
<li>
<i class="fa fa-dashboard"></i> Dashboard / Edit Post
</li>
</ol>

</div><!-- col-lg-12 Ends -->
</div><!-- Row Ends -->

<div class="row"><!-- 2 row Starts -->
<div class="col-lg-12"><!-- col-lg-12 Starts -->
<div class="panel panel-default"><!-- panel panel-default Starts -->

<div class="panel-heading"><!-- panel-heading Starts -->
<h3 class="panel-title">
<i class="fa fa-money fa-fw"></i> Edit Post
</h3>
</div><!-- panel-heading Ends -->

<div class="panel-body"><!-- panel-body Starts -->
<form class="form-horizontal" method="post" enctype="multipart/form-data"><!-- form-horizontal Starts -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Title</label>
<div class="col-md-6">
<input type="text" name="post_title" class="form-control" required value="<?php echo $post_title; ?>">
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Author</label>
<div class="col-md-6">
<input type="text" name="post_author" class="form-control" required value="<?php echo $post_author; ?>">
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Keywords</label>
<div class="col-md-6">
<input type="text" name="post_keywords" class="form-control" required value="<?php echo $post_keywords; ?>">
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Category</label>
<div class="col-md-6">
<select name="cat" class="form-control">
<?php

$get_cat = "select * from categories where category_id='$post_cat'";
$run_cat = mysqli_query($con,$get_cat);
$row_cat = mysqli_fetch_array($run_cat);
$cat_id = $row_cat['category_id'];
$cat_title = $row_cat['category_title'];
echo "<option value='$cat_id'>$cat_title</option>";

$get_cat_more = "select * from categories";
$run_cat_more = mysqli_query($con,$get_cat_more);

while($row_cat_more=mysqli_fetch_array($run_cat_more)){

$cat_more_id = $row_cat_more['category_id'];
$cat_more_title = $row_cat_more['category_title'];

echo "<option value='$cat_more_id'>$cat_more_title</option>";

}

?>
</select>
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Image</label>
<div class="col-md-6">
<input type="file" name="post_image" class="form-control" required>
<img src="post_images/<?php echo $post_image; ?>" width="70" height="70">
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Content</label>
<div class="col-md-6">
<textarea name="post_content" class="form-control" rows="6" cols="19"> <?php echo $post_content; ?> </textarea>

</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" class="btn btn-primary form-control">

</div>

</div><!-- form-group Ends -->

</form><!-- form-horizontal Ends -->
</div><!-- panel-body Ends -->

</div><!-- panel panel-default Ends -->
</div><!-- col-lg-12 Ends -->
</div><!-- 2 row Ends -->


</body>
</html>

<?php

if(isset($_POST['submit'])){

$post_title = $_POST['post_title'];
$post_cat = $_POST['cat'];
$post_author = $_POST['post_author'];
$post_keywords = $_POST['post_keywords'];
$post_image = $_FILES['post_image']['name'];
$temp_name = $_FILES['post_image']['tmp_name'];
$post_content = $_POST['post_content'];
$post_date = date("d M Y");

move_uploaded_file($temp_name,"post_images/$post_image");

$update_posts = "update blog_posts set category_id='$post_cat',post_title='$post_title',post_date='$post_date',post_author='$post_author',post_keywords='$post_keywords',post_image='$post_image',post_content='$post_content' where post_id='$post_id'";

$run_update = mysqli_query($con,$update_posts);

if($run_update){
echo "<script>alert('Post has been Updated')</script>";
echo "<script>window.open('index.php?view_posts','_self')</script>";

}

}

?>

<?php } ?>