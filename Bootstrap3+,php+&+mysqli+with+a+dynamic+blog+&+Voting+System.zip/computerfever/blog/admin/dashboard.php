<?php
@session_start();
include("includes/connection.php");

if(!isset($_SESSION['admin_email'])){
echo "<script>window.open('login.php','_self')</script>";
}else{



?>

<div class="row"><!---1 row Starts -->

<div class="col-lg-12"><!-- col-lg-12 Starts -->

<h1 class="page-header">
Dashboard
</h1>

<ol class="breadcrumb"><!-- breadcrumb Starts -->
<li class="active">
<i class="fa fa-dashboard"></i> Dashboard
</li>
</ol><!-- breadcrumb Ends -->

</div><!-- col-lg-12 Ends -->

</div><!--- 1 row Ends -->

<div class="row"><!-- 2 row Starts-->

<div class="col-lg-3 col-md-6"><!-- col-lg-3 col-md-6 Starts -->
<div class="panel panel-primary"><!-- panel panel-primary Starts -->

<div class="panel-heading"><!-- panel-heading Starts -->

<div class="row"><!-- panel-heading row Starts -->

<div class="col-xs-3"><!-- col-xs-3 Starts -->
<i class="fa fa-comments fa-5x"></i>
</div><!-- col-xs-3 Ends -->

<div class="col-xs-9 text-right"><!-- col-xs-9 text-right Starts -->
<div class="huge"><?php echo $count_comments; ?></div>

<div>Comments</div>

</div><!-- col-xs-9 text-right Ends -->

</div><!-- panel-heading row Ends -->

</div><!-- panel-heading Ends -->

<a href="index.php?view_comments">
<div class="panel-footer"><!-- panel-footer Starts -->
<span class="pull-left">View Details</span>
<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
<div class="clearfix"></div>
</div><!-- panel-footer Ends -->
</a>

</div><!-- panel panel-primary Ends -->
</div><!-- col-lg-3 col-md-6 Ends -->

<div class="col-lg-3 col-md-6"><!-- col-lg-3 col-md-6 Starts -->
<div class="panel panel-green"><!-- panel panel-green Starts -->
<div class="panel-heading"><!-- panel-heading Starts -->
<div class="row"><!-- panel-heading row Starts -->
<div class="col-xs-3"><!--- col-xs-3 Starts -->
<i class="fa fa-tasks fa-5x"></i>
</div><!--- col-xs-3 Ends -->

<div class="col-xs-9 text-right">
<div class="huge"><?php echo $count_posts; ?></div>
<div>Posts</div>
</div>

</div><!-- panel-heading row Ends -->
</div><!-- panel-heading Ends -->

<a href="index.php?view_posts">

<div class="panel-footer"><!-- panel-footer Starts -->
<span class="pull-left">View Details</span>
<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
<div class="clearfix"></div>
</div><!-- panel-footer Ends -->

</a>

</div><!-- panel panel-green Ends -->
</div><!-- col-lg-3 col-md-6 Ends -->

<div class="col-lg-3 col-md-6"><!-- col-lg-3 col-md-6 Starts-->
<div class="panel panel-yellow"><!-- panel panel-yellow Starts-->

<div class="panel-heading"><!-- panel-heading Starts-->

<div class="row"><!-- Row Starts-->

<div class="col-xs-3"><!-- col-xs-3 Starts -->
<i class="fa fa-shopping-cart fa-5x"></i>
</div><!-- col-xs-3 Ends -->

<div class="col-xs-9 text-right"><!--- col-xs-9 text-right Starts-->
<div class="huge"><?php echo $count_categories; ?></div>
<div>Categories</div>
</div><!--- col-xs-9 text-right Ends-->


</div><!-- Row Ends-->

</div><!-- panel-heading Ends-->

<a href="index.php?view_cats">

<div class="panel-footer"><!-- panel-footer Starts ---->
<span class="pull-left">View Details</span>
<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
<div class="clearfix"></div>
</div><!-- panel-footer Ends ---->

</a>

</div><!-- panel panel-yellow Ends-->
</div><!-- col-lg-3 col-md-6 Ends-->

<div class="col-lg-3 col-md-6"><!-- col-lg-3 col-md-6 Starts-->
<div class="panel panel-red"><!-- Panel panel-red Starts-->

<div class="panel-heading"><!-- panel-heading Starts-->

<div class="row"><!-- Row Starts -->

<div class="col-xs-3"><!-- col-xs-3 Starts-->
<i class="fa fa-support fa-5x"></i>
</div><!-- col-xs-3 Ends-->

<div class="col-xs-9 text-right"><!-- col-xs-9 text-right Starts-->
<div class="huge"><?php echo $count_admins; ?></div>
<div>Users</div>
</div><!-- col-xs-9 text-right Ends-->

</div><!-- Row Ends -->

</div><!-- panel-heading Ends-->

<a href="index.php?view_users">

<div class="panel-footer"><!-- panel-footer Starts-->
<span class="pull-left">View Details</span>
<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
<div class="clearfix"></div>
</div><!-- panel-footer Ends-->

</a>

</div><!-- Panel panel-red Ends-->
</div><!-- col-lg-3 col-md-6 Ends-->

</div><!-- 2 row Ends -->

<div class="row"><!--- 3 row Starts -->
<div class="col-lg-8"><!-- col-lg-8 Starts -->

<div class="panel panel-primary"><!-- panel panel-primary Starts -->
<div class="panel-heading"><!-- panel-heading Starts -->
<h3 class="panel-title"> <i class="fa fa-money fa-fw"></i> New Comments </h3>
</div><!-- panel-heading Ends -->

<div class="panel-body"><!-- panel-body Starts -->
<div class="table-responsive"><!-- table-responsive Starts -->
<table class="table table-bordered table-hover table-striped"><!-- table table-bordered table-hover table-striped Starts -->

<thead>
<tr>
<th>Comment Name</th>
<th>Comment Email</th>
<th>Comment Url</th>
<th>Comment Date</th>
<th>Comment Post</th>
</tr>
</thead>

<tbody>

<?php

$get_comments = "select * from comments where status='unapprove' order by 1 DESC LIMIT 0,4";

$run_comments = mysqli_query($con,$get_comments);

while ($row_comments= mysqli_fetch_array($run_comments)){

$post_id = $row_comments['post_id'];
$comment_name = $row_comments['comment_name'];
$comment_date = $row_comments['comment_date'];
$comment_email = $row_comments['comment_email'];
$comment_url = $row_comments['comment_url'];

$get_posts = "select * from blog_posts where post_id='$post_id'";
$run_posts = mysqli_query($con,$get_posts);
$row_posts = mysqli_fetch_array($run_posts);
$post_title = $row_posts['post_title'];

?>

<tr>
<td><?php echo $comment_name; ?></td>
<td><?php echo $comment_email; ?></td>
<td><?php echo $comment_url; ?></td>
<td><?php echo $comment_date; ?></td>
<td><?php echo $post_title; ?></td>
</tr>

<?php } ?>

</tbody>

</table><!-- table table-bordered table-hover table-striped Ends -->
</div><!-- table-responsive Ends -->

<div class="text-right"><!--- text-right Starts -->
<a href="index.php?view_comments">
View All Comments <i class="fa fa-arrow-circle-right"></i>
</a>
</div><!--- text-right Ends -->

</div><!-- panel-body Ends -->

</div><!-- panel panel-primary Ends -->
</div><!-- col-lg-8 Ends -->

<div class="col-md-4"><!-- col-md-4 Starts -->
<div class="panel"><!-- panel Starts -->
<div class="panel-body"><!-- panel-body Starts -->

<div class="thumb-info mb-md">
<img src="admin_images/<?php echo $admin_image; ?>" class="rounded img-responsive">

<div class="thumb-info-title"><!-- thumb-info-title Starts -->

<span class="thumb-info-inner"><?php echo $admin_name; ?></span>
<span class="thumb-info-type"><?php echo $admin_job; ?></span>

</div><!-- thumb-info-title Ends -->

</div>

<div class="mb-md"><!-- mb-md Starts -->

<div class="widget-content-expanded"><!-- widget-content-expanded Starts -->

<i class="fa fa-user"></i> <span>Email: </span> <?php echo $admin_email; ?> <br>
<i class="fa fa-user"></i> <span>Country: </span> <?php echo $admin_country; ?> <br>
<i class="fa fa-user"></i> <span>Contact: </span> <?php echo $admin_contact; ?> <br>

</div><!-- widget-content-expanded Ends -->

<hr class="dotted short">

<h5 class="text-muted">About</h5>
<p>
<?php echo $admin_about; ?>
</p>

</div><!-- mb-md Ends -->

</div><!-- panel-body Ends -->
</div><!-- panel Ends -->

</div><!-- col-md-4 Ends -->

</div><!--- 3 row Ends -->

<?php } ?>