<?php
@session_start();
include("includes/connection.php");

if(!isset($_SESSION['admin_email'])){
echo "<script>window.open('login.php','_self')</script>";
}else{



?>

<?php

if(isset($_GET['unapprove'])){

$unapprove_id = $_GET['unapprove'];

$unapprove_comment = "update comments set status='unapprove' where comment_id='$unapprove_id'";

$run_unapprove = mysqli_query($con,$unapprove_comment);

echo "<script>alert('Comment has been unapproved Successfully')</script>";
echo "<script>window.open('index.php?view_comments','_self')</script>";

}

if(isset($_GET['approve'])){

$approve_id = $_GET['approve'];

$approve_comment = "update comments set status='approve' where comment_id='$approve_id'";

$run_approve = mysqli_query($con,$approve_comment);

echo "<script>alert('Comment has been approved successfully')</script>";
echo "<script>window.open('index.php?view_comments','_self')</script>";

}

?>





<?php  } ?>