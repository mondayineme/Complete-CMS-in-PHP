<?php
@session_start();
include("includes/connection.php");

if(!isset($_SESSION['admin_email'])){
echo "<script>window.open('login.php','_self')</script>";
}else{



?>

<?php

if(isset($_GET['delete_comment'])){

$delete_id = $_GET['delete_comment'];
$delete_comment_query = "delete from comments where comment_id='$delete_id'";
$run_delete = mysqli_query($con,$delete_comment_query);

echo "<script>alert('Comment has been deleted successfully')</script>";
echo "<script>window.open('index.php?view_comments','_self')</script>";

}

?>



<?php } ?>