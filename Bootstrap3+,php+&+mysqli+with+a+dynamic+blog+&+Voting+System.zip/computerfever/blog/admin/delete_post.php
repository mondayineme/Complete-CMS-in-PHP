<?php
@session_start();
include("includes/connection.php");

if(!isset($_SESSION['admin_email'])){
echo "<script>window.open('login.php','_self')</script>";
}else{


?>

<?php

if(isset($_GET['delete_post'])){

$delete_id = $_GET['delete_post'];

$delete_post = "delete from blog_posts where post_id='$delete_id'";

$run_delete = mysqli_query($con,$delete_post);

echo "<script>alert('One Post Has Been Deleted')</script>";
echo "<script>window.open('index.php?view_posts','_self')</script>";

}

?>

<?php } ?>