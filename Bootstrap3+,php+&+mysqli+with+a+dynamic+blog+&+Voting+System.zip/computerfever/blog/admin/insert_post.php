<?php
@session_start();
include("includes/connection.php");

if(!isset($_SESSION['admin_email'])){
echo "<script>window.open('login.php','_self')</script>";
}else{


?>
<!DOCTYPE html>
<html>

<head>

<title>Insert Post</title>



<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>

</head>

<body>

<div class="row"><!-- row Starts -->
<div class="col-lg-12"><!-- col-lg-12 Starts -->
<ol class="breadcrumb"><!-- breadcrumb Starts -->
<li class="active"> <i class="fa fa-dashboard"></i> Dashboard / Insert Post  </li>

</ol><!-- breadcrumb Ends -->
</div><!-- col-lg-12 Ends -->
</div><!-- row Ends -->

<div class="row"><!-- row Starts -->
<div class="col-lg-12"><!-- col-lg-12 Starts -->

<div class="panel panel-default"><!-- panel panel-default Starts -->
<div class="panel-heading"><!-- panel-heading Starts -->
<h3 class="panel-title"> <i class="fa fa-money fa-fw"></i> Insert Post </h3>
</div><!-- panel-heading Ends -->

<div class="panel-body"><!-- panel-body Starts -->

<form class="form-horizontal" action="insert_post.php" method="post" enctype="multipart/form-data"> <!--- form-horizontal Starts --->

<div class="form-group"><!--- form-group Starts -->
<label class="col-md-3 control-label"> Post Title </label>
<div class="col-md-6">
<input required type="text" name="post_title" class="form-control">
</div>
</div><!--- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label"> Post Author </label>

<div class="col-md-6">
<input required type="text" name="post_author" class="form-control">
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts --->
<label class="col-md-3 control-label"> Post Keywords </label>

<div class="col-md-6">
<input required type="text" name="post_keywords" class="form-control">
</div>

</div><!-- form-group Ends --->

<div class="form-group"><!-- form-group Starts --->
<label class="col-md-3 control-label">Post category</label>
<div class="col-md-6">
<select name="cat" class="form-control">
<option>Select a Category</option>
<?php
$get_cat = "select * from categories";
$run_cat = mysqli_query($con,$get_cat);
while($row_cat=mysqli_fetch_array($run_cat)) {
$cat_id = $row_cat['category_id'];
$cat_title = $row_cat['category_title'];
echo "<option value='$cat_id'>$cat_title</option>";
}
?>
</select>

</div>

</div><!-- form-group Ends --->

<div class="form-group"><!-- Form-group Starts -->
<label class="col-md-3 control-label">Post an Image</label>
<div class="col-md-6">
<input required type="file" name="post_image" class="form-control">
</div>
</div><!-- Form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label">Post Content</label>
<div class="col-md-6">
<textarea name="post_content" class="form-control" rows="6" cols="19"></textarea>
</div>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->
<label class="col-md-3 control-label"></label>
<div class="col-md-6">
<input type="submit" name="submit" class="btn btn-primary form-control">
</div>

</div><!-- form-group Ends -->

</form><!--- form-horizontal Ends --->

</div><!-- panel-body Ends -->

</div><!-- panel panel-default Ends -->

</div><!-- col-lg-12 Ends -->
</div><!-- row Ends -->

</body>


</html>
<?php
if(isset($_POST['submit'])){
$post_title = $_POST['post_title'];
$post_author = $_POST['post_author'];
$post_keywords = $_POST['post_keywords'];
$post_cat = $_POST['cat'];
$post_content = $_POST['post_content'];
$post_date = date("d M Y");

$post_image = $_FILES['post_image']['name'];
$temp_name = $_FILES['post_image']['tmp_name'];

move_uploaded_file($temp_name,"post_images/$post_image");

$insert_post = "insert into blog_posts (category_id,post_title,post_date,post_author,post_keywords,post_image,post_content) values ('$post_cat','$post_title','$post_date','$post_author','$post_keywords','$post_image','$post_content')";

$run_insert = mysqli_query($con,$insert_post);

if($run_insert){
echo "<script>alert('Post has been Inserted')</script>";
echo "<script>window.open('index.php?view_posts','_self')</script>";
}

}

?>

<?php } ?>