<!DOCTYPE html>
<html>
<head>
<title>Voting System</title>
<link rel="stylesheet" href="style.css" >
</head>
<body>

<div class="title"><!-- Title Starts -->
<h1>Who do you think is better in Wrestling?</h1>
</div><!-- Title Ends -->

<div class="container"><!-- Container Starts -->
<form action="index.php" method="post" align="center" ><!-- Form Starts -->

<img src="images/john_cena.jpg" >

<img src="images/brock_lesnar.jpg">

<img src="images/roman_reigns.jpg">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="john_cena" value="Vote For John Cena" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="brock_lesnar" value="Vote For Brock Lesnar" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="roman_reigns" value="Vote For Roman Reigns" >

</form><!-- Form Ends -->

<?php

$con = mysqli_connect("localhost","root","","vote_system");

if(isset($_POST['john_cena'])){

$vote_john_cena = "update votes set john_cena=john_cena+1";
$run_john_cena = mysqli_query($con,$vote_john_cena);

if($run_john_cena){
echo "<h2 style='text-align:center;'>Your Vote Has Been Cast To John Cena</h2>";
echo "<h2 style='text-align:center;'><a href='index.php?results'>View Results</a></h2>";
}

}

if(isset($_POST['brock_lesnar'])){

$vote_brock_lesnar = "update votes set brock_lesnar=brock_lesnar+1";
$run_brock_lesnar = mysqli_query($con,$vote_brock_lesnar);

if($run_brock_lesnar){
echo "<h2 style='text-align:center;'>Your Vote Has Been Cast To Brock Lesnar</h2>";
echo "<h2 style='text-align:center;'><a href='index.php?results'>View Results</a></h2>";
}

}

if(isset($_POST['roman_reigns'])){

$vote_roman_reigns = "update votes set roman_reigns=roman_reigns+1";
$run_roman_reigns = mysqli_query($con,$vote_roman_reigns);

if($run_roman_reigns){
echo "<h2 style='text-align:center;'>Your Vote Has Been Cast To Roman Reigns</h2>";
echo "<h2 style='text-align:center;'><a href='index.php?results'>View Results</a></h2>";
}

}

// View results Code Starts ///

if(isset($_GET['results'])){

$result_query = "select * from votes";

$run_result = mysqli_query($con,$result_query);

$row_result = mysqli_fetch_array($run_result);

$john_cena = $row_result['john_cena'];
$brock_lesnar = $row_result['brock_lesnar'];
$roman_reigns = $row_result['roman_reigns'];

$count = $john_cena+$brock_lesnar+$roman_reigns;

$per_john_cena = round($john_cena*100/$count) . "%"; 
$per_brock_lesnar = round($brock_lesnar*100/$count) . "%"; 
$per_roman_reigns = round($roman_reigns*100/$count) . "%"; 

echo "

<div style='background:orange; padding:10px; text-align:center;'>
<center>

<h2>Results So Far</h2>

<p style='background:black;color:white;width:300px;padding:10px;'>
<b>John Cena :</b> $john_cena ($per_john_cena)
</p>

<p style='background:black;color:white;width:300px;padding:10px;'>
<b>Brock Lesnar :</b> $brock_lesnar ($per_brock_lesnar)
</p>

<p style='background:black;color:white;width:300px;padding:10px;'>
<b>Roman Reigns :</b> $roman_reigns ($per_roman_reigns)
</p>

</center>
</div>


";

}

// View results Code Ends ///

?>

</div><!-- Container Ends -->

<div class="title"><!-- Title Starts -->
<h1>Created By computerfever.com</h1>
</div><!-- Title Ends -->



</body>
</html>