<!DOCTYPE html>
<?php
$expire = time()+60*60*24*30;

setcookie("user","www.computerfever.com",$expire);

?>

<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>


<?php

echo $_COOKIE['user'] . "<br><br><br>";

print_r($_COOKIE);

?>

</body>
</html>
