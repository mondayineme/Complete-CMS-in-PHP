<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>


<?php
// 4 Parameters are Important to send an email to users in php

$to = "tahir.ahmed186@gmail.com";

$subject = "Important Notice";

$message = "We are informing you about our recent courses.";

$from = "sad.ahmed22224@gmail.com";

mail($to,$subject,$message,$from);

echo "<h2>Email has been sent</h2>";

?>

</body>
</html>
