<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>
<form action="post_get.php" method="post">
User Name:<input type="text" name="value1">

User Email:<input type="text" name="value2">

<input type="submit" name="submit" value="Submit">

</form>

<?php

 echo $user_name = @$_POST['value1'] . "<br>" ;
 
 echo $user_email = @$_POST['value2'];


?>

</body>
</html>
