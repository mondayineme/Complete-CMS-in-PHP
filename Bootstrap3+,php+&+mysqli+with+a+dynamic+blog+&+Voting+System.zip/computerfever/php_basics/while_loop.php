<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$num = 0;

while($num<31){
$num++;
echo "Day Number is: " . $num . "<br>";
}

echo "<br><br><br>";

$num2 = 31;

while($num2>0){
$num2--;
echo "Day Number is: " . $num2 . "<br>";
}

?>

</body>
</html>
