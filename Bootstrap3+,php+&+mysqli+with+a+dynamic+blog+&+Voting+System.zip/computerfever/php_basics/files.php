<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

$file = fopen("test.txt","w");

$text = "Hi, My Name is Honey";

fwrite($file,$text);

fclose($file);

?>

</body>
</html>
