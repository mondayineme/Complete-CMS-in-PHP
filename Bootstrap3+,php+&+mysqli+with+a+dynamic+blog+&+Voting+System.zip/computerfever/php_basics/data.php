<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>
<table width="600" border="3" align="center" bgcolor="pink">
<tr>
<th>First Name</th>
<th>Last Name</th>
<th>Email</th>
</tr>

<tr>
<td>John</td>
<td>Doe</td>
<td>John@gmail.com</td>
</tr>

<tr>
<td>Mary</td>
<td>Moe</td>
<td>mary@gmail.com</td>
</tr>

<tr>
<td>July</td>
<td>Dooley</td>
<td>july@gmail.com</td>
</tr>

</table>

</body>
</html>