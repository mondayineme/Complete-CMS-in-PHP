<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

$computer = array("Monitor is used for display data","Ram is used for memory","Hard disk is used for saving data","Motherboad is used for functioning","Keyboard is used for typing","Mouse is used for controlling","Speakers is used for voice");

echo "<b>What is the usage of Monitor?</b><br>" . $computer[0] . "<br>";
echo "<b>What is the usage of Ram?</b><br>" . $computer[1] . "<br>";
echo "<b>What is the usage of Hard Disk?</b><br>" . $computer[2] . "<br>";
echo "<b>What is the usage of Mother boad?</b><br>" . $computer[3] . "<br>";
echo "<b>What is the usage of Keyboard?</b><br>" . $computer[4] . "<br>";
echo "<b>What is the usage of Mouse?</b><br>" . $computer[5] . "<br>";
echo "<b>What is the usage of Speakers?</b><br>" . $computer[6] . "<br><br>";

$countries = array();

$countries['pk'] = "Pakistan";
$countries['ind'] = "India";
$countries['sri'] = "Srilanka";
$countries['ame'] = "America";
$countries['uk'] = "United Kingdom";

echo "Welcome to " . $countries['sri'];

?>

</body>
</html>
