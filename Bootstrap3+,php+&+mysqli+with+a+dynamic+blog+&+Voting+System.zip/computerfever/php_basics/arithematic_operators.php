<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$a = 21;
$b = 10;

echo $a + $b . "<br>";

echo $a - $b . "<br>";

echo $a * $b . "<br>";

echo $a / $b . "<br>";

echo $a % $b . "<br>";


?>

</body>
</html>
