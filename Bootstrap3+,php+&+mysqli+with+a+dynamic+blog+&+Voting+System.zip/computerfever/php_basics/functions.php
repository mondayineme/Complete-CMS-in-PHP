<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

function myfun($val_1,$val_2){

echo "Hello World<br>";

echo "Hello $val_1 My name is $val_2";

}
myfun('Saady','Honey');
echo "<br><br>";
myfun('Asif','Brock Lesner');



?>

</body>
</html>
