<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

// 1. && (and)

// 2. || (or)

// 3. !

$username = "Saady";

$password = "test123"; 

$email = "sad.ahmed22224@gmail.com";

if($username == "Saady" && $password == "test123" || $email == "sad.ahmed2224@gmail.com" && $password == "test123"){
echo "you are login<br>";
}
else{
echo "You are not login please try again<br>";
}

$val = "value1";

if($val != "value2"){
echo "Condition is true";
}
else{
echo "Condition is false";
}

?>

</body>
</html>
