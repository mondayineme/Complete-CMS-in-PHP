<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

$book = "ye";

$copy = "ye";

$news_paper = "ye";

$magazine = "ye";

if($book == "yes"){

echo "We got the book";

}

elseif($copy == "yes"){

echo "We got the copy";

}

elseif($news_paper == "yes"){

echo "We got the news paper";

}

elseif($magazine == "yes"){

echo "We got the magazine";

}

else{

echo "We got nothing";

}

?>

</body>
</html>
