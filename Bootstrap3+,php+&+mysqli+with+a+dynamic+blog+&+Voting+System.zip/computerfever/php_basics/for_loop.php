<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

for($year=1980; $year<2017; $year++){

echo "Year Number is:" . $year . "<br>";

}

echo "<br><br><br>";

for($year2=2017; $year2>1980; $year2--){

echo "Year Number is:" . $year2 . "<br>";

}
?>

</body>
</html>
