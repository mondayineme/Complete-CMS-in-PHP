<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$text = "Hello World How are you<br>";



$number1 = 4555;
$number2 = 3333;

$num = $number1+$number2;

$all = $num + 134 - 55 . "<br>" . $text;

echo $all;

?>

</body>
</html>
