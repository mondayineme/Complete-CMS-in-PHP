<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

echo "<h2>Hello World 9+9</h2>" , "How are you?";
print "<h2>Hello World</h2>" . "How are you?";

echo 9+9;

?>

</body>
</html>
