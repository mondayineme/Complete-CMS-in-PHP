<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$name = "king";

switch($name){
case 'Saady' : echo("The name is Saady");
break;

case 'Honey' : echo("The name is Honey");
break;

case 'Asif' : echo("The name is Asif");
break;

case 'Undertaker' : echo("The name is Undertaker");
break;

default : echo("No case Match");

}

?>

</body>
</html>
