<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

echo ucfirst("hello world<br><br>");

echo lcfirst("Hello World<br><br>");

echo ucwords("hello world<br><br>");

echo strtoupper("hello world<br><br>");

echo strtolower("HELLO WORLD<br><br>");

?>

</body>
</html>
