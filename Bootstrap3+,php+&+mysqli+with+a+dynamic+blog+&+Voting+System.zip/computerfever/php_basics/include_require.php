<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
include("dat.php");
include_once("data.php");

echo "<br><br><br>";

require("dat.php");
require_once("data.php");

echo "<br><br>Hello World";

?>

</body>
</html>
