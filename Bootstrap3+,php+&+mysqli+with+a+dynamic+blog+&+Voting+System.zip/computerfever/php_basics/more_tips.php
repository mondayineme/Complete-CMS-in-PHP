<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

echo date("D/M/d/Y - h:m:s") . "<br><br><br>";

$invoice = mt_rand();

echo $invoice . "<br><br>";

$change = md5($invoice);

echo $change;

?>

</body>
</html>
