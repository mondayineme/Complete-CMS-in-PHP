<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$num = 12;

do{
$num++;
echo "Month Number is: " . $num . "<br>";
}while($num<12);

echo "<br><br><hr>";

$num2 = 13;

do{
$num2--;
echo "Month Number is: " . $num2 . "<br>";
}while($num2>1);
?>

</body>
</html>
