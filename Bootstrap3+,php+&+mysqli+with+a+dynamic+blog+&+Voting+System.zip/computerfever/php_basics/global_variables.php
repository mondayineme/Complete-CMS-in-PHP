<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

echo $_SERVER['REMOTE_ADDR'];

$_POST[''];

$_GET[''];

$_FILES[''];

$_SESSION[''];

$_COOKIE[''];

?>

</body>
</html>
