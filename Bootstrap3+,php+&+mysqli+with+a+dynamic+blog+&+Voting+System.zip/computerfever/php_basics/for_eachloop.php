<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$softwares = array("photoshop","coreldraw","illustrator","ms office");
foreach($softwares as $values){
echo $values . "<br>";
}

?>

</body>
</html>
