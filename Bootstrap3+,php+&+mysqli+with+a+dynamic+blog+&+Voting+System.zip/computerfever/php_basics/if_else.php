<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
$var1 = 10;
$var2 = 12;
if($var1 == $var2){

echo "This condition is true";

}else{
echo "This condition is wrong";

}

echo "<br><br>";

$person = "Brock Lesner";

$age = 21;

if($age<20){

echo $person . "  is very young";

}
else{

echo $person . "  is not young";

}


?>

</body>
</html>
