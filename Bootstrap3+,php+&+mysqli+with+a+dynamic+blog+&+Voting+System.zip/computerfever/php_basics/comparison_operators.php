<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php
// 1. == (equal to)

// 2. != (not equal to)

// 3. > (greater than)

// 4. < (less than)

// 5. >= (greater than or equal to)

// 6. <= (less than or equal to)

$a = 30;
$b = 30;

if($a >= $b){

echo "Every thing is fine";

}
else{

echo "Every thing is not fine";

}


?>

</body>
</html>
