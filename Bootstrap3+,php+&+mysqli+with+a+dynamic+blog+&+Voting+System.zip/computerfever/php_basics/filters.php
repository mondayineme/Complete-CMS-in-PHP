<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<form action="filters.php" method="post">

<input type="text" name="url">

<input type="submit" name="submit" value="Submit Now">

</form>

<?php

if(isset($_POST['submit'])){

$url = $_POST['url'];

if(filter_var($url, FILTER_VALIDATE_URL)){

echo "<h2>URL is Valid & Ok </h2>";

}

else{

echo "<h2>URL is not Valid</h2>";

}

}

?>

</body>
</html>
