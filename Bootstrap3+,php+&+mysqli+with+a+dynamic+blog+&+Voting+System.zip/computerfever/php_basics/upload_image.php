<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<form action="upload_image.php" method="post" enctype="multipart/form-data">

Select a File: <input type="file" name="image">

<input type="submit" name="upload" value="Upload File">

</form>

<?php

if(isset($_POST['upload'])){

$image = $_FILES['image']['name'] ;

$image_tmp = $_FILES['image']['tmp_name'];

move_uploaded_file($image_tmp,"images/$image");

echo "<br><img src='images/$image' width='300' height='200'>";

}

?>

</body>
</html>
