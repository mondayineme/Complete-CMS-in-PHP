<!DOCTYPE html>
<html>
<head>
<title>PHP Basics Course</title>

</head>

<body>

<?php

$string = "This is a simple text";

$integer = 123;

$booleans1 = true;
$booleans2 = false;

$array = array("photoshop","freehand","coreldraw");

var_dump($booleans1);

?>

</body>
</html>
